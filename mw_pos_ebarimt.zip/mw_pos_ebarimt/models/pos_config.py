from odoo import models, fields

class PosConfig(models.Model):
    _inherit = 'pos.config'

    is_with_ebarimt = fields.Boolean(string="Enable Ebarimt")
    eb_district_code = fields.Char(string="District Code")
    eb_tin = fields.Char(string="POS TIN")
    company_tin = fields.Char(string="Company TIN")
    ebarimt_url = fields.Char(string="Ebarimt API URL")
    is_not_vat_incl = fields.Boolean(string="Price not VAT included")
