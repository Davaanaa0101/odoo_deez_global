from odoo import api, models, fields


class EbarimtCategory(models.Model):
    _name = 'ebarimt.category'
    _description = 'EBarimt Category'
    _inherit = ['mail.thread']

    name = fields.Char(string='Ебаримт Ангилал', tracking=True)
    code = fields.Integer(string='Код', tracking=True)
