import { Component, useState } from "@odoo/owl";
// ... your other imports

export class ProductScreen extends Component {
    // ... your existing code

    setup() {
        super.setup();

        this.pos = usePos();
        this.ui = useState(useService("ui"));
        this.state = useState({
            ebarimtChecked: false,
            vatChecked: false,
            // other states you need
        });

        // Load saved checkbox state from current order if exists
        const order = this.currentOrder;
        if (order.checkboxState) {
            this.state.ebarimtChecked = order.checkboxState.ebarimtChecked || false;
            this.state.vatChecked = order.checkboxState.vatChecked || false;
        }
    }

    toggleCheckbox(name) {
        this.state[name] = !this.state[name];
        const order = this.currentOrder;
        if (!order.checkboxState) {
            order.checkboxState = {};
        }
        order.checkboxState[name] = this.state[name];
    }

    get currentOrder() {
        return this.pos.get_order();
    }

    // ... rest of your existing methods
}
