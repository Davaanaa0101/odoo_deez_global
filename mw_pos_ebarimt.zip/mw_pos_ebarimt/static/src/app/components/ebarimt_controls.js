/** @odoo-module **/

import { Component, useState } from "@odoo/owl";

export class EbarimtControls extends Component {
    setup() {
        this.state = useState({
            bill_type: null,
            register: '',
            company_name: '',
        });
    }

    changeBillType(ev) {
        this.state.bill_type = ev.target.value;
    }

    inputValueCheck(ev) {
        this.state.register = ev.target.value;
        // Here you'd implement logic to validate and fetch company name
        this.state.company_name = this.state.register ? `Company ${this.state.register}` : '';
    }
}

EbarimtControls.template = "mw_pos_ebarimt.EbarimtControls";
