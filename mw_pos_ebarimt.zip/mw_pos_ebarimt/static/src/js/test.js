/** @odoo-module **/

import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { patch } from "@web/core/utils/patch";
import { useState } from "@odoo/owl";
import Registries from "@point_of_sale/Registries";

patch(PaymentScreen.prototype, "mw_pos_ebarimt.PaymentScreen", {
    setup() {
        // Call the original setup
        this._super?.();

        // Initialize your state with current order bill_type or null
        this.state = useState({
            bill_type: this.currentOrder?.bill_type || null,
            utga: null,
        });
    },

    async _isOrderValid() {
        console.log("this.state.bill_type ", this.state.bill_type);
        this.currentOrder.bill_type = this.state.bill_type;

        if (this.currentOrder.bill_type === "5" && !this.currentOrder.get_client()) {
            const { confirmed } = await this.showPopup("ConfirmPopup", {
                title: this.env._t("Please select the Customer"),
                body: this.env._t("You need to select the customer before you can validate an order."),
            });
            if (confirmed) {
                this.selectClient();
            }
            return false;
        } else {
            return await this._super();
        }
    },

    toggleIsToInvoice() {
        this._super();
        if (
            this.currentOrder.is_to_invoice() &&
            this.currentOrder.bill_type !== "B2B_INVOICE"
        ) {
            this.currentOrder.bill_type = "B2B_INVOICE";
        }

        if (
            !this.currentOrder.is_to_invoice() &&
            this.currentOrder.bill_type === "B2B_INVOICE"
        ) {
            this.currentOrder.bill_type = "B2C_RECEIPT";
        }
        this.state.bill_type = this.currentOrder.bill_type;
    },

    changeBillType(event) {
        this.currentOrder.bill_type = event.target.value;
        this.state.bill_type = this.currentOrder.bill_type;
        if (this.state.bill_type === "B2B_RECEIPT") {
            $(".isCompany").show();
            $(".company-name").text("");
        } else {
            $(".isCompany").hide();
            this.currentOrder.customerReg = null;
            this.currentOrder.customerName = "";
        }
        if (this.state.bill_type === "5") {
            this.toggleIsToInvoice();
        }
    },

    async inputValueCheck() {
        const inputData = document.getElementById("register").value;
        if (inputData.length > 6) {
            console.log("resp+++ " + inputData);
            try {
                const your_return_value = await this.rpc({
                    model: "pos.order",
                    method: "get_merchant_info",
                    args: [inputData],
                });
                if (your_return_value.found === false) {
                    alert(inputData + " регистрийн дугаартай байгууллага бүртгэлгүй байна!");
                    document.getElementById("company_name").innerHTML = "";
                } else {
                    console.log("value.name " + your_return_value.name);
                    document.getElementById("company_name").innerHTML = your_return_value.name;
                    this.currentOrder.customerReg = inputData;
                    this.currentOrder.customerName = your_return_value.name;
                }
            } catch (error) {
                console.error("RPC error:", error);
            }
        } else {
            document.getElementById("company_name").innerHTML = "";
        }
    }
});

// If you want to register explicitly, do:
Registries.Component.extend(PaymentScreen, patch);

export default PaymentScreen;
