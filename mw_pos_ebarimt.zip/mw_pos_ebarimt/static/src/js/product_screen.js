/** @odoo-module **/

import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { patch } from "@web/core/utils/patch";
import { useState } from "@odoo/owl";

patch(PaymentScreen.prototype, {
    setup() {
        super.setup?.();

        this.state = useState({
            bill_type: this.currentOrder?.bill_type || null,
        });

        this.changeBillType = this.changeBillType.bind(this);
        this.inputValueCheck = this.inputValueCheck.bind(this);
    },

    async _isOrderValid() {
        this.currentOrder.bill_type = this.state.bill_type;

        if (this.currentOrder.bill_type === "5" && !this.currentOrder.get_client()) {
            const { confirmed } = await this.showPopup("ConfirmPopup", {
                title: this.env._t("Please select the Customer"),
                body: this.env._t("You need to select the customer before you can validate an order."),
            });
            if (confirmed) {
                this.selectClient();
            }
            return false;
        }

        return await super._isOrderValid();
    },

    toggleIsToInvoice() {
        super.toggleIsToInvoice?.();

        if (this.currentOrder.is_to_invoice() && this.currentOrder.bill_type !== "B2B_INVOICE") {
            this.currentOrder.bill_type = "B2B_INVOICE";
        }

        if (!this.currentOrder.is_to_invoice() && this.currentOrder.bill_type === "B2B_INVOICE") {
            this.currentOrder.bill_type = "B2C_RECEIPT";
        }

        this.state.bill_type = this.currentOrder.bill_type;
    },

    changeBillType(event) {
        this.currentOrder.bill_type = event.target.value;
        this.state.bill_type = this.currentOrder.bill_type;

        const companyFields = document.querySelectorAll(".isCompany");
        const nameField = document.querySelector(".company-name");

        if (this.state.bill_type === "B2B_RECEIPT") {
            companyFields.forEach(el => el.style.display = "block");
            if (nameField) nameField.textContent = "";
        } else {
            companyFields.forEach(el => el.style.display = "none");
            this.currentOrder.customerReg = null;
            this.currentOrder.customerName = "";
        }

        if (this.state.bill_type === "5") {
            this.toggleIsToInvoice();
        }
    },


    async inputValueCheck() {
        const inputData = document.getElementById("register")?.value || "";
        if (inputData.length > 6) {
            try {
                const result = await this.rpc({
                    model: "pos.order",
                    method: "get_merchant_info",
                    args: [inputData],
                });

                if (!result.found) {
                    alert(`${inputData} регистрийн дугаартай байгууллага бүртгэлгүй байна!`);
                    document.getElementById("company_name").innerHTML = "";
                } else {
                    document.getElementById("company_name").innerHTML = result.name;
                    this.currentOrder.customerReg = inputData;
                    this.currentOrder.customerName = result.name;
                }
            } catch (error) {
                console.error("RPC error:", error);
            }
        } else {
            document.getElementById("company_name").innerHTML = "";
        }
    }
});
