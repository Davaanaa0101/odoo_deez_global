# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': "Davaa POS ebarimt",
    'version': '19.2.1',
    'category': 'Point of sale',
    'sequence': 40,
    'summary': 'Manage Point of sale ebarimt',
    'description': """ПОС ибаримт модуль
                - 
                    """,
    'depends': ['point_of_sale','stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/pos_config_view.xml',
        'views/account_tax_views.xml',
        'views/point_of_sale.xml',
        #'views/pos_assets.xml',
        'views/product_category_view.xml',
        'data/tax_data.xml'
    ],
    'assets': {
        'point_of_sale._assets_pos':
            [
            'mw_pos_ebarimt/static/src/app/**/*',
            'mw_pos_ebarimt/static/src/js/receipt_patch.js',
            #'mw_pos_ebarimt/static/src/xml/ebarimt_templates.xml',
            'mw_pos_ebarimt/static/src/js/product_screen.js',
            'mw_pos_ebarimt/static/src/xml/pos_templates.xml',
            'mw_pos_ebarimt/static/src/xml/pos_receipt.xml',
            #'mw_pos_ebarimt/static/src/xml/test.xml',
            #'mw_pos_ebarimt/static/src/js/test.js',
            ],
    },
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
