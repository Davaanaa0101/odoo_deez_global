# -*- coding: utf-8 -*-
from odoo import api, models, fields

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    ecategory_id = fields.Many2one('ebarimt.category' , string='Е баримт ангилал' , tracking=True , store=True)