/** @odoo-module **/

import { patch } from '@web/core/utils/patch';
import { ProductScreen } from '@point_of_sale/app/screens/product_screen/product_screen';
import { useState } from '@odoo/owl';
import { Checkbox } from '@web/core';

const originalSetup = ProductScreen.prototype.setup;

patch(ProductScreen.prototype, {
    setup() {
        if (originalSetup) {
            originalSetup.call(this);
        }

        this.state = useState({
            ebarimtChecked: false,
            vatChecked: false,
        });

        const order = this.env?.pos?.get_order?.() ?? null;

        if (order) {
            this.state.ebarimtChecked = order.ebarimt_checked || false;
            this.state.vatChecked = order.vat_checked || false;
        }

        console.log('ProductScreen patched setup, initial state:', this.state);
    },

    toggleCheckbox(name) {
        console.log('toggleCheckbox called with:', name, 'current state:', this.state[name]);
        this.state[name] = !this.state[name];
        const order = this.env?.pos?.get_order?.();
        if (order) {
            if (name === 'ebarimtChecked') {
                order.ebarimt_checked = this.state[name];
            } else if (name === 'vatChecked') {
                order.vat_checked = this.state[name];
            }
            order.trigger('change', order);
            order.saveChanges?.();
            console.log('Order updated:', order);
        }
    },
});
