/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { EbarimtControls } from "../components/ebarimt_controls";

patch(PaymentScreen.prototype, {
    mounted() {
        super.mounted();
        if (this.pos.config.is_with_ebarimt) {
            const target = this.el.querySelector(".payment-buttons");
            if (target) {
                const container = document.createElement("div");
                target.insertAdjacentElement('afterend', container);
                const ebarimt = new EbarimtControls(this.env);
                ebarimt.mount(container);
            }
            console.log('payment-buttons target:', target);
            if (target) {
                // ...
            } else {
                console.warn('payment-buttons element NOT found');
            }
        }
    }
});
