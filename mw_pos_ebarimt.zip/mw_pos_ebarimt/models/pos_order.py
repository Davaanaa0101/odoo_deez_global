from odoo import api, fields, models, _
import requests
import json
from .constants import *
from odoo.exceptions import UserError
import logging
_logger = logging.getLogger(__name__)

class PosOrder(models.Model):
    _inherit = 'pos.order'
    
    def create_from_ui(self, orders, draft=False):
        result = super().create_from_ui(orders, draft)
        for order in result:
            selected_option = order.radio_state
            if selected_option == 'option1':
                _logger.info("Option 1 was selected! Do something.")
            elif selected_option == 'option2':
                _logger.info("Option 2 (Company) was selected! Do something.")
            elif selected_option == 'option3':
                _logger.info("Option 3 was selected! Do something.")
            elif selected_option == 'option4':
                _logger.info("Option 4 was selected! Do something.")
        return result


    def _apply_invoice_payments(self):
        '''Төлбөр үүсгэж төлөхгүй
        '''
        return True

    bill_id = fields.Char(string='Bill ID', help="EBarimt Bill Id.")
    bill_printed_date = fields.Datetime(string='Bill Printed Date')
    bill_type = fields.Selection([(BILL_TYPE_NOTAX, 'No Tax'),
                                  (BILL_TYPE_INDIVIDUAL, 'Individual'),
                                  (BILL_TYPE_COMPANY, 'Company'),
                                  (BILL_TYPE_INVOICE, 'Invoice'),
                                  (BILL_TYPE_B2B_INVOICE,'Invoice C'),
                                  (BILL_TYPE_NOTSEND, u'НӨАТ илгээхгүй')], default=BILL_TYPE_INDIVIDUAL)
    bill_mac_address = fields.Char(string='Bill MAC Address')
    tax_type = fields.Char(string='Bill Tax Type', compute='_tax_type')
    amount_tax_vat = fields.Float(compute='_compute_taxes', string='Taxes VAT', digits=0)
    amount_tax_city = fields.Float(compute='_compute_taxes', string='Taxes City', digits=0)
    customer_register = fields.Char('Customer Register')
    customer_name = fields.Char('Customer Name')
    ebarimt_date = fields.Datetime(string='Е баримт огноо' ,store = True)
    ebarimt_note = fields.Char(string = 'Ebarimt Note')

    def _amount_tax(self, line, fiscal_position_id, ebarimt_tax_type_code):
        taxes = line.tax_ids.filtered(lambda
                                          t: t.company_id.id == line.order_id.company_id.id and t.ebarimt_tax_type_id.code == ebarimt_tax_type_code)

        if fiscal_position_id:
            taxes = fiscal_position_id.map_tax(taxes)

        price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
        cur = line.order_id.pricelist_id.currency_id
        taxes = \
            taxes.compute_all(price, cur, line.qty, product=line.product_id, partner=line.order_id.partner_id or False)[
                'taxes']
        val = 0.0
        for c in taxes:
            val += c.get('amount', 0.0)
        return val

    @api.depends('lines.price_subtotal_incl', 'lines.discount', 'lines')
    def _compute_taxes(self):
        for order in self:
            currency = order.pricelist_id.currency_id
            if not currency or len(currency) != 1:
                _logger.error(f"Invalid currency on order '{order.name}'")
                currency = self.env.user.company_id.currency_id  # Fallback to company currency

            order.amount_tax_vat = currency.round(
                sum(order._amount_tax(line, order.fiscal_position_id, '1') for line in order.lines)
            )
            order.amount_tax_city = currency.round(
                sum(order._amount_tax(line, order.fiscal_position_id, '4') for line in order.lines)
            )

    @api.model
    def _order_fields(self, ui_order):
        order_fields = super(PosOrder, self)._order_fields(ui_order)
        order_fields['customer_register'] = ui_order.get('customerReg', False)
        order_fields['customer_name'] = ui_order.get('customerName', False)
        order_fields['bill_type'] = ui_order.get('bill_type')
        order_fields['ebarimt_checked'] = ui_order.get('ebarimt_checked', False)
        order_fields['vat_checked'] = ui_order.get('vat_checked', False)

        if order_fields.get('partner_id', False):
            if self.env['res.partner'].browse(order_fields['partner_id']).nuat_no_send:
                ines = order_fields['lines']
                for item in lines:
                    del item[2]['tax_ids']
        return order_fields

    @api.model
    def _payment_fields(self, order, ui_paymentline):
        order_fields = super(PosOrder, self)._payment_fields(order, ui_paymentline)

        if ui_paymentline.get('utga', False):
            order_fields.update({'name': ui_paymentline.get('utga', '')})
        return order_fields


    @api.depends('lines')
    def _tax_type(self):
        self.tax_type = None
        if any(self.env['ebarimt.tax.type'].browse(t.ebarimt_tax_type_id.id).code =='1' for t in self.lines.tax_ids):
            self.tax_type = 'TAX_TYPE_VAT'
        if all(self.env['ebarimt.tax.type'].browse(t.ebarimt_tax_type_id.id).code == '4' for t in self.lines.tax_ids):
            self.tax_type = 'TAX_TYPE_CITY'
        if any(self.env['ebarimt.tax.type'].browse(t.ebarimt_tax_type_id.id).code == '3' for t in self.lines.tax_ids):
            self.tax_type = 'TAX_TYPE_VAT_ZERO'
        if self.partner_id and self.partner_id.nuat_no_send:
            self.tax_type = 'TAX_TYPE_VAT_FREE'

    @api.model
    def get_ebarimt(self, server_ids , data=''):
        ebarimt_data = ''

        for s in server_ids:
            order = self.env['pos.order'].browse(s['id'])
            if order.bill_type == BILL_TYPE_NOTAX or order.bill_type==BILL_TYPE_NOTSEND:
                return ebarimt_data

            # if order.to_invoice:
            #     return ebarimt_data
            ebarimt_data = order.set_ebarimt(data)
            data=json.loads(ebarimt_data)
            dd=data.get("type",'')
            order.bill_id = data.get("id",'')
            order.bill_type= dd
            order.ebarimt_date= data.get("date",'')
            
        return ebarimt_data
    
    @api.model
    def set_ebarimt(self, data ,):
        self._tax_type()
        self._compute_taxes()
        # НӨАТ Чөлөөлөгдөх үед авах 
        if self.partner_id and self.partner_id.nuat_no_send == True and self.partner_id.vat:
            # tin_url = "https://api.ebarimt.mn/api/info/check/getTinInfo?regNo={0}".format(self.partner_id.vat)
            # tin_result = requests.get(tin_url)
            # regNo = json.loads(tin_result.text).get('data') if tin_result.status_code == 200 else False
            header={}
            header['Content-Type'] = 'application/json'
            url='http://103.50.205.181:5000/get_regno'
            _logger.info('VAT: urlInput ----> : %s' % (data['customerTin']))
            tin_result = requests.post(url,data= json.dumps((data['customerTin'])), headers=header)
            _logger.info('VAT: tin_result ----> : %s' % tin_result)
            regNo = tin_result.text
            data=json.loads(data)
            vat=0
            city_tax=0
            total_amount_vat=0
            total_amount=round(data.get('totalAmount',0),6)
            if total_amount:
                vat=round(total_amount/1.1,6)*0.1
                total_amount_vat = round(total_amount-vat,6)
            data['totalAmount']=total_amount_vat
            data['totalVAT']=0
            data['totalCityTax']=0
            data['customerTin']=regNo
            data['taxProductCode']="318"
            
            for d in data['receipts']:                                    
                d['totalAmount']=total_amount_vat
                d['totalVAT']=0
                d['totalCityTax']=0
                d['taxProductCode']="318"
                d['taxType']="VAT_FREE"
                for i in d['items']:
                    # i['totalAmount']=total_amount_vat
                    i['totalVAT']=0
                    i['totalCityTax']=0
                    i['taxProductCode']="318"
                    # i['unitPrice'] = total_amount_vat
                    
            for p in data['payments']:
                p['paidAmount'] = total_amount_vat
        # НӨАТ 0 хувь үед авах 
        elif self.tax_type =="TAX_TYPE_VAT_ZERO" or self.session_id.config_id.is_not_vat_incl:
            data=json.loads(data)
            vat=0
            city_tax=0
            total_amount_vat=0
            total_amount=round(data.get('totalAmount',0),6)
            data['totalAmount']=total_amount
            data['totalVAT']=0
            data['totalCityTax']=0
            data['taxProductCode']="501"
            
            for d in data['receipts']:                                    
                d['totalAmount']=total_amount
                d['totalVAT']=0
                d['totalCityTax']=0
                d['taxProductCode']="501"
                d['taxType']="VAT_ZERO"
                for j in d['items']:
                    j['totalCityTax']=0
                    j['taxProductCode']="501"
                    j['totalVAT']=0
                    for i in d['items']:
                        i['totalVAT']=0
                    
            for p in data['payments']:
                p['paidAmount'] = total_amount
        else:
            data=json.loads(data)
            regNo = ''
            if len(data.get('customerTin',''))>0:
                # tin_url = "https://api.ebarimt.mn/api/info/check/getTinInfo?regNo={0}".format((data['customerTin']))
                # tin_result = requests.get(tin_url)
                # regNo = json.loads(tin_result.text).get('data') if tin_result.status_code == 200 else False
                header={}
                header['Content-Type'] = 'application/json'
                url='http://103.50.205.181:5000/get_regno'
                _logger.info('VAT: urlInput ----> : %s' % (data['customerTin']))
                tin_result = requests.post(url,data= json.dumps((data['customerTin'])), headers=header)
                _logger.info('VAT: tin_result ----> : %s' % tin_result)
                regNo = tin_result.text
                # regNo=data['customerTin']
                
            vat=0
            city_tax=0
            total_amount=round(data.get('totalAmount',0),6)
            if self.amount_tax_vat:
                vat=round(total_amount/1.1,6)*0.1
            if self.amount_tax_city:
                city_tax=round(total_amount / 112*2,6)
            # if city_tax:
            #     total_amount+=city_tax
            data['totalAmount']=total_amount
            data['totalVAT']=vat
            data['totalCityTax']=city_tax
            if len(data.get('customerTin',''))>0:
                data['customerTin']=regNo
            for d in data['receipts']:                                    
                d['totalAmount']=total_amount
                d['totalVAT']=vat
                d['totalCityTax']=city_tax
                for i in d['items']:
                    i['totalCityTax']=city_tax
        # url='http://203.34.37.106:7080/rest/receipt'
        url=''
        if self.session_id.config_id.ebarimt_url:
            url=self.session_id.config_id.ebarimt_url+'/rest/receipt'
        aaa = json.dumps(data)
        print ('data12312 ',data)
        x = requests.post(url, json = data)
        return x.text
    
    def get_ebarimt_nuhuj(self ):
        ebarimt_data = ''

        for order in self:
            # if order.bill_type == BILL_TYPE_NOTAX:
            #     return ebarimt_data

            # if order.to_invoice:
            #     return ebarimt_data
            if order.bill_id:
                raise UserError(_('Аль хэдийн олгсоон байна.'))
            ebarimt_data = order.set_ebarimt_nuhuj(order)
            data=json.loads(ebarimt_data)
            dd=data.get("type",'')
            order.bill_id = data.get("id",'')
            order.bill_type= dd
            
        return ebarimt_data    
                

    def set_ebarimt_nuhuj(self,order):
        total_amount=order.amount_paid
        total_vat=round(total_amount/1.1,6)*0.1
        type=order.bill_type
        receipts=[]
        items=[]
        for line in order.lines:
            
            tmp={
                        "name": line.product_id.name,
                        "barCode": '',
                        "barCodeType": "UNDEFINED",
                        "classificationCode": "8843000",
                        "measureUnit": "ш",
                        "qty": line.qty,
                        "unitPrice": line.price_unit,
                        "totalBonus": 0,
                        "totalVAT": total_vat,
                        "totalCityTax": 0,
                        "totalAmount": line.subprice_subtotal_incl,
                        # "tax_ids":taxes
                        }
            items.append(tmp)  

            tmp2={
                    "totalAmount":total_vat,
                    "totalVAT":total_vat,
                     "taxType": "VAT_ABLE",
                     "merchantTin":order.session_id.config_id.eb_tin,
                     "items":items,
                    }
            # paidAmount=amountTotal;
            receipts.append(tmp2)            
                 
        data={
                    "totalAmount": total_amount,
                    "totalVAT": total_vat,
                    "totalCityTax": 0,
                    "districtCode": order.session_id.config_id.eb_district_code,
                    "merchantTin": order.session_id.config_id.eb_tin,#"73101472838",
                    "branchNo": "001",
                    "posNo": "001",
                    "customerTin": "",
                    "consumerNo": "",
                    "type": type,
                    "inactiveId": "",
                    "reportMonth": '2024-01-15',
                        "receipts": receipts,
                    "payments": [
                        {
                            "code": "CASH",
                            "status": "PAID",
                            "paidAmount": total_amount
                        }
                    ]
                    };        
                                                                     
        # url='http://203.34.37.106:7080/rest/receipt'
        url=''
        if self.session_id.config_id.ebarimt_url:
            url=self.session_id.config_id.ebarimt_url+'/rest/receipt'
        x = requests.post(url, json = data)
        return x.text                

    @api.model
    def get_merchant_info(self, urlInput):
        """ Get metchant info from ebarimt REST api """
        header={}
        header['Content-Type'] = 'application/json'
        url='http://103.50.205.181:5000/get_info'
        _logger.info('VAT: urlInput ----> : %s' % urlInput)
        resp = requests.post(url,data= json.dumps(urlInput), headers=header)
        _logger.info('VAT: resp ----> : %s' % resp.text)
        try:
            data = json.loads(resp.text)
        except Exception as e:
            raise Warning(_('Error'), _('Could not connect to json device. \n%s') % e.message)

        # resp = requests.get(url=('http://info.ebarimt.mn/rest/merchant/info?regno=' + urlInput))
        # try:
        #     data = json.loads(resp.text)
        # except Exception as e:
        #     raise Warning(_('Error'), _('Could not connect to json device. \n%s') % e.message)
        return data

    @api.model
    def get_merchant_tin(self, urlInput):
        """ Get metchant info from ebarimt REST api """
        # resp = requests.get(url=('https://api.ebarimt.mn/api/info/check/getTinInfo?regNo=' + urlInput))
        header={}
        header['Content-Type'] = 'application/json'
        url='http://103.50.205.181:5000/get_info'
        _logger.info('VAT: urlInput ----> : %s' % urlInput)
        resp = requests.post(url,data= json.dumps(urlInput), headers=header)
        _logger.info('VAT: resp ----> : %s' % resp.text)
        try:
            data = json.loads(resp.text)
        except Exception as e:
            raise Warning(_('Error'), _('Could not connect to json device. \n%s') % e.message)
        return data
#####################EBarimt butsaah #####################
    def generate_return_bill_json(self):
        data = {}
        data['id'] = self.bill_id
        data['date'] = self.ebarimt_date.strftime('%Y-%m-%d %H:%M:%S')
        # data['amount'] = '%s'%(self.amount_paid)
        return data
    
    def action_returnBill(self):
        r = self.generate_return_bill_json()
        _logger.info('VAT: GET data ----> : %s' % r)
        if self.bill_id :
            data = ''
            etax_url = self.session_id.config_id.ebarimt_url
            if not etax_url:
                raise UserError("Е-баримтын сервэрийн IP-г тохируулж өгнө үү!")
            _logger.info(u'=================E tax URL----------------- {0}'.format(etax_url+'/res/receipt'))
            headers = {
                'Content-Type': 'application/json'
            }
            _logger.info(u'=================E tax json data----------------- {0}'.format(json.dumps(r['data'])))
            response = requests.delete(etax_url+'/res/receipt', headers=headers, data=json.dumps(r), verify=True)
            _logger.info('VAT: GET action_returnBill ----> : %s' % response)
            if response.status_code == 200:
                data = response.json()
                _logger.info("Ebarimt send response json --- : %s", data)
            else:
                _logger.info("Ebarimt send response error --- : %s", response.content)
                raise UserError(_('Ebarimt connection error! status code: %s' % response.status_code))
            ebarimt_note = ''
            if self.ebarimt_note:
                ebarimt_note = self.ebarimt_note+' | '+'REFUND FULL '+self.bill_id
            else:
                ebarimt_note = self.name+' | '+'REFUND FULL '+self.bill_id
            return self.write({'ebarimt_note':ebarimt_note,'ebarimt_state':'return' ,  'return_success':data})
   
    def _get_etax_url(self):
        # Компани мэдээлэл дээрээс etax URL авах
        if self.session_id.config_id.ebarimt_url:
            return self.session_id.config_id.ebarimt_url
        else:
            return False
        
    def _action_sendData(self):
        etax_url = self._get_etax_url()
        for company in etax_url:
            etax_url = etax_url+'/sendData'
            _logger.info(u'=================E tax URL----------------- {0}'.format(etax_url))
            header = {'Content-Type':'application/json'}
            send_data_log = self.env['ebarimt.send.data.log'].create({'request_url': etax_url})
            response = requests.get(etax_url, data={}, headers=header)
            data = response.json()
            send_data_log.write({'response_data': data, 'response_status': response.content})
            _logger.info(u'=================E tax Send RESPONSE json data----------------- {0}'.format(data))
            _logger.info(u'=================E tax Send RESPONSE----------------- {0}'.format(response.content))


class PosConfig(models.Model):
    _inherit = 'pos.config'
    
    eb_district_code = fields.Char(string='districtCode',)
    eb_tin = fields.Char(string='merchantTin',)
    
    is_with_ebarimt = fields.Boolean(string='Ebarimt3.0 олгох?')
    ebarimt_url = fields.Char(string='Ebarimt url')
    is_not_vat_incl = fields.Boolean(string='НӨАТ төлөгч биш бол?')
    
    company_tin = fields.Char(string='Company TIN',)
    
    
class ResPartner(models.Model):
    _inherit = 'res.partner'

    nuat_no_send = fields.Boolean(string='Е-Баримт илгээхгүй харилцагч')
